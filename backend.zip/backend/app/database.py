"""Small SQLite persistence layer for the local demo."""
import sqlite3
from pathlib import Path
from contextlib import contextmanager
DB_PATH = Path(__file__).resolve().parents[1] / "data" / "vendor_onboarding.sqlite3"

@contextmanager
def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS applications(application_ref TEXT PRIMARY KEY, state TEXT NOT NULL, decision_status TEXT, version INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS application_versions(id INTEGER PRIMARY KEY AUTOINCREMENT, application_ref TEXT NOT NULL, version INTEGER NOT NULL, submission_json TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(application_ref, version), FOREIGN KEY(application_ref) REFERENCES applications(application_ref));
        CREATE TABLE IF NOT EXISTS evaluations(id INTEGER PRIMARY KEY AUTOINCREMENT, application_ref TEXT NOT NULL, version INTEGER NOT NULL, result_json TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(application_ref) REFERENCES applications(application_ref));
        CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY AUTOINCREMENT, application_ref TEXT NOT NULL, slot_id TEXT NOT NULL, original_filename TEXT NOT NULL, sha256 TEXT NOT NULL, stored_path TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, application_ref TEXT NOT NULL, version INTEGER NOT NULL, seq INTEGER NOT NULL, event_json TEXT NOT NULL, created_at TEXT NOT NULL);
        """)
